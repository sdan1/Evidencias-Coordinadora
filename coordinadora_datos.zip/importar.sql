-- =========================================================
-- Importación de datos - Coordinadora (PostgreSQL)
-- Ejecutar desde la carpeta donde están los CSV:
--   psql -U postgres -d coordinadora -f importar.sql
-- =========================================================
SET client_encoding = 'UTF8';

BEGIN;

-- Limpia las tablas (orden inverso a las dependencias)
TRUNCATE novelty, delivery, follow_up, package, shipment,
         employee, logistics_center, addressee, sender,
         city, state, country RESTART IDENTITY CASCADE;

-- Carga en orden de dependencias (padres -> hijos)
\copy country(country_id, name) FROM 'country.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8')
\copy state(state_id, name, country_id) FROM 'state.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8')
\copy city(city_id, name, state_id) FROM 'city.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8')
\copy logistics_center(center_code, name, address, phone, city_id) FROM 'logistics_center.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8')
\copy sender(sender_id, full_name, document_type, document_number, address, phone, contact_name, email, city_id) FROM 'sender.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8')
\copy addressee(addressee_id, full_name, document_type, document_number, address, mobile_phone, contact_name, purchase_order_number, order_number, invoice_reference, email, city_id) FROM 'addressee.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8')
\copy employee(employee_id, name, job_role, phone, center_code) FROM 'employee.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8')
\copy shipment(tracking_number, barcode, initial_status, admission_datetime, service_type, declared_value, freight_value, payment_method, estimated_delivery_date, sender_id, addressee_id) FROM 'shipment.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8')
\copy package(package_id, physical_weight, length, width, height, volumetric_weight, packaging_type, content_description, declared_value, notes, tracking_number) FROM 'package.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8')
\copy follow_up(follow_up_id, current_status, event_datetime, notes, tracking_number, center_code, employee_id) FROM 'follow_up.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8')
\copy delivery(delivery_id, delivery_datetime, receiver_name, receiver_id_number, relationship_to_addressee, digital_proof_of_delivery, tracking_number) FROM 'delivery.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8')
\copy novelty(novelty_id, novelty_cause, novelty_datetime, attempts_made, actions_taken, tracking_number) FROM 'novelty.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8')

-- Ajusta las secuencias (si los id son SERIAL/IDENTITY) para que el próximo INSERT no choque
DO $$
DECLARE r record; seq text;
BEGIN
  FOR r IN SELECT * FROM (VALUES
      ('country','country_id'),('state','state_id'),('city','city_id'),
      ('sender','sender_id'),('addressee','addressee_id'),('employee','employee_id'),
      ('package','package_id'),('follow_up','follow_up_id'),
      ('delivery','delivery_id'),('novelty','novelty_id')) AS t(tbl, col)
  LOOP
    seq := pg_get_serial_sequence(r.tbl, r.col);
    IF seq IS NOT NULL THEN
      EXECUTE format('SELECT setval(%L, (SELECT COALESCE(MAX(%I),1) FROM %I))', seq, r.col, r.tbl);
    END IF;
  END LOOP;
END $$;

COMMIT;

-- Verificación
SELECT 'country' t, COUNT(*) FROM country UNION ALL
SELECT 'state', COUNT(*) FROM state UNION ALL
SELECT 'city', COUNT(*) FROM city UNION ALL
SELECT 'logistics_center', COUNT(*) FROM logistics_center UNION ALL
SELECT 'employee', COUNT(*) FROM employee UNION ALL
SELECT 'sender', COUNT(*) FROM sender UNION ALL
SELECT 'addressee', COUNT(*) FROM addressee UNION ALL
SELECT 'shipment', COUNT(*) FROM shipment UNION ALL
SELECT 'package', COUNT(*) FROM package UNION ALL
SELECT 'follow_up', COUNT(*) FROM follow_up UNION ALL
SELECT 'delivery', COUNT(*) FROM delivery UNION ALL
SELECT 'novelty', COUNT(*) FROM novelty;
