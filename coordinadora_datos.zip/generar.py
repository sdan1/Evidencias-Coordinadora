import json, csv, random, os
from datetime import datetime, timedelta, date

random.seed(2026)
OUT = "csv"
os.makedirs(OUT, exist_ok=True)

def write(name, header, rows):
    with open(f"{OUT}/{name}.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)
    print(name, len(rows))

# ---------------- country / state / city ----------------
data = json.load(open("colombia.json", encoding="utf-8"))
write("country", ["country_id", "name"], [[1, "Colombia"]])

states, cities = [], []
city_by_name = {}          # (dep, city) -> id
city_state = {}            # city_id -> state_id
cid = 1
for i, d in enumerate(data, start=1):
    states.append([i, d["departamento"], 1])
    for c in d["ciudades"]:
        cities.append([cid, c, i])
        city_by_name[(d["departamento"], c)] = cid
        city_state[cid] = i
        cid += 1
write("state", ["state_id", "name", "country_id"], states)
write("city", ["city_id", "name", "state_id"], cities)
dep_name = {s[0]: s[1] for s in states}
cities_of_state = {}
for c in cities:
    cities_of_state.setdefault(c[2], []).append(c[0])

# ---------------- logistics_center (50) ----------------
# (departamento, ciudad, sigla, cantidad de centros, indicativo fijo)
center_plan = [
    ("Cundinamarca", "Bogotá", "BOG", 7, "601"), ("Antioquia", "Medellín", "MDE", 4, "604"),
    ("Valle del Cauca", "Cali", "CLO", 4, "602"), ("Atlántico", "Barranquilla", "BAQ", 3, "605"),
    ("Bolívar", "Cartagena de Indias", "CTG", 2, "605"), ("Santander", "Bucaramanga", "BGA", 2, "607"),
    ("Norte de Santander", "Cúcuta", "CUC", 2, "607"), ("Norte de Santander", "Ocaña", "OCV", 1, "607"),
    ("Risaralda", "Pereira", "PEI", 1, "606"), ("Caldas", "Manizales", "MZL", 1, "606"),
    ("Quindío", "Armenia", "AXM", 1, "606"), ("Tolima", "Ibagué", "IBE", 1, "608"),
    ("Huila", "Neiva", "NVA", 1, "608"), ("Meta", "Villavicencio", "VVC", 1, "608"),
    ("Boyacá", "Tunja", "TUN", 1, "608"), ("Nariño", "Pasto", "PSO", 1, "602"),
    ("Cauca", "Popayán", "PPN", 1, "602"), ("Magdalena", "Santa Marta", "SMR", 1, "605"),
    ("Cesar", "Valledupar", "VUP", 1, "605"), ("Córdoba", "Montería", "MTR", 1, "604"),
    ("Sucre", "Sincelejo", "SNC", 1, "605"), ("La Guajira", "Riohacha", "RCH", 1, "605"),
    ("Chocó", "Quibdó", "UIB", 1, "604"), ("Caquetá", "Florencia", "FLA", 1, "608"),
    ("Putumayo", "Mocoa", "MCO", 1, "608"), ("Casanare", "Yopal", "EYP", 1, "608"),
    ("Arauca", "Arauca", "AUC", 1, "607"), ("Amazonas", "Leticia", "LET", 1, "608"),
    ("Guainía", "Inírida", "PDA", 1, "608"), ("Guaviare", "San José del Guaviare", "SJE", 1, "608"),
    ("Vaupés", "Mitú", "MVP", 1, "608"), ("Vichada", "Puerto Carreño", "PCR", 1, "608"),
    ("San Andrés y Providencia", "San Andrés", "ADZ", 1, "608"),
]
tipos_centro = ["Centro Logístico", "Terminal de Carga", "Centro de Distribución", "Punto de Servicio", "Centro Operativo"]
calles = ["Calle", "Carrera", "Avenida", "Diagonal", "Transversal"]

def direccion():
    return f"{random.choice(calles)} {random.randint(1,120)}{random.choice(['','A','B','C',''])} # {random.randint(1,99)}-{random.randint(1,99)}"

centers = []
centers_of_city = {}
for dep, ciudad, sigla, n, ind in center_plan:
    city_id = city_by_name[(dep, ciudad)]
    for k in range(1, n + 1):
        code = f"CO-{sigla}-{k:02d}"
        nombre = f"Coordinadora {tipos_centro[0] if k == 1 else random.choice(tipos_centro[1:])} {ciudad}" + (f" {k}" if n > 1 and k > 1 else "")
        centers.append([code, nombre, direccion() + (" Bodega " + str(random.randint(1,20)) if random.random()<0.5 else ""),
                        f"{ind}{random.randint(2000000, 7999999)}", city_id])
        centers_of_city.setdefault(city_id, []).append(code)
assert len(centers) == 50, len(centers)
write("logistics_center", ["center_code", "name", "address", "phone", "city_id"], centers)

hub_bog = centers_of_city[city_by_name[("Cundinamarca", "Bogotá")]][0]
center_of_state = {}
for c in centers:
    center_of_state.setdefault(city_state[c[4]], []).append(c[0])

def center_for_city(city_id):
    if city_id in centers_of_city:
        return random.choice(centers_of_city[city_id])
    return center_of_state.get(city_state[city_id], [hub_bog])[0]

# ---------------- nombres ----------------
nombres_h = ["Juan", "Carlos", "Andrés", "Luis", "Jorge", "Diego", "Santiago", "Sebastián", "Camilo", "Felipe", "Alejandro", "Daniel", "David", "Mateo", "Nicolás", "Julián", "Óscar", "Fabián", "Héctor", "Javier", "Miguel", "Ricardo", "Wilson", "Edwin", "Jhon", "Brayan", "Kevin", "Esteban", "Germán", "Alexander"]
nombres_m = ["María", "Laura", "Ana", "Paula", "Valentina", "Daniela", "Camila", "Natalia", "Carolina", "Diana", "Andrea", "Sofía", "Juliana", "Mariana", "Sandra", "Claudia", "Paola", "Lorena", "Yuliana", "Leidy", "Angélica", "Marcela", "Luisa", "Gabriela", "Isabella", "Viviana", "Tatiana", "Adriana", "Luz Marina", "Gloria"]
apellidos = ["Rodríguez", "Gómez", "González", "Martínez", "García", "López", "Hernández", "Sánchez", "Ramírez", "Pérez", "Díaz", "Moreno", "Rojas", "Jiménez", "Vargas", "Castro", "Ortiz", "Rubio", "Suárez", "Torres", "Quintero", "Pabón", "Jaime", "Navarro", "Carrascal", "Ascanio", "Sanjuan", "Pacheco", "Mejía", "Restrepo", "Ospina", "Cárdenas", "Ramos", "Guerrero", "Mendoza", "Arias", "Salazar", "Cabrera", "Barrera", "Bermúdez", "Vega", "Palacios", "Caballero", "Duarte", "Peñaranda", "Lozano", "Montoya", "Zapata"]

def persona():
    n = random.choice(nombres_h + nombres_m)
    if random.random() < 0.35:
        n += " " + random.choice(nombres_h + nombres_m)
    return f"{n} {random.choice(apellidos)} {random.choice(apellidos)}"

def email_de(nombre, dominio=None):
    import unicodedata
    s = unicodedata.normalize("NFKD", nombre).encode("ascii", "ignore").decode().lower().split()
    user = f"{s[0]}.{s[-2] if len(s)>2 else s[-1]}{random.randint(1,999)}"
    return f"{user}@{dominio or random.choice(['gmail.com','hotmail.com','outlook.com','yahoo.com'])}"

def celular():
    return f"3{random.choice(['00','01','02','04','05','10','11','12','13','14','15','16','17','18','20','21','22','23','24','50','51'])}{random.randint(1000000,9999999)}"

usados = set()
def doc_num(tipo):
    while True:
        if tipo == "NIT":
            n = f"{random.randint(800000000, 901999999)}-{random.randint(0,9)}"
        elif tipo == "CE":
            n = str(random.randint(100000, 9999999))
        elif tipo == "PA":
            n = f"{random.choice(['AB','PE','VE','EC','US'])}{random.randint(100000,999999)}"
        else:
            n = str(random.choice([random.randint(1000000000, 1127999999), random.randint(10000000, 99999999)]))
        if n not in usados:
            usados.add(n); return n

# ciudades ponderadas: capitales y grandes ciudades con más peso
peso_ciudad = {}
for dep, ciudad, _, n, _ in center_plan:
    peso_ciudad[city_by_name[(dep, ciudad)]] = 6 * n
all_city_ids = [c[0] for c in cities]
pesos = [peso_ciudad.get(c, 0.35) for c in all_city_ids]
def ciudad_random():
    return random.choices(all_city_ids, weights=pesos)[0]

# ---------------- sender (200) ----------------
empresas_pre = ["Distribuidora", "Comercializadora", "Inversiones", "Textiles", "Tienda", "Importadora", "Laboratorios", "Calzado", "Tecnología", "Ferretería", "Droguería", "Confecciones", "Agroinsumos", "Papelería", "Electrodomésticos"]
empresas_suf = ["del Norte", "Andina", "La Esperanza", "Santander", "El Caribe", "Express", "Colombia", "Los Andes", "Del Valle", "Integral", "Global", "Nacional", "La 14", "San José", "Oriente", "Pacífico", "Central", "Moda Total", "Digital", "Hogar"]
senders = []
for i in range(1, 201):
    empresa = random.random() < 0.55
    city = ciudad_random()
    if empresa:
        nom = f"{random.choice(empresas_pre)} {random.choice(empresas_suf)} {random.choice(['S.A.S.','S.A.S.','Ltda.','S.A.'])}"
        tipo = "NIT"; contacto = persona()
        dom = "".join(ch for ch in nom.lower().split()[0] if ch.isalpha()) + ".com.co"
        mail = email_de(contacto, dom)
    else:
        nom = persona(); tipo = random.choices(["CC", "CE", "PA"], [92, 6, 2])[0]
        contacto = nom; mail = email_de(nom)
    senders.append([i, nom, tipo, doc_num(tipo), direccion(), celular() if not empresa or random.random()<0.5 else f"60{random.randint(1,8)}{random.randint(2000000,7999999)}",
                    contacto, mail, city])
write("sender", ["sender_id", "full_name", "document_type", "document_number", "address", "phone", "contact_name", "email", "city_id"], senders)

# ---------------- addressee (200) ----------------
addressees = []
for i in range(1, 201):
    nom = persona(); tipo = random.choices(["CC", "CE", "TI", "PA", "NIT"], [85, 6, 3, 2, 4])[0]
    if tipo == "NIT":
        nom = f"{random.choice(empresas_pre)} {random.choice(empresas_suf)} S.A.S."
    contacto = persona() if tipo == "NIT" else nom
    addressees.append([i, nom, tipo, doc_num(tipo), direccion() + random.choice(["", "", f" Apto {random.randint(1,15)}0{random.randint(1,4)}", f" Barrio {random.choice(['Centro','La Ermita','El Prado','San Antonio','Villa Real','Los Pinos','Santa Clara'])}"]),
                       celular(), contacto,
                       f"OC-{random.randint(100000,999999)}", f"PED-{2026}{random.randint(10000,99999)}",
                       f"FE-{random.choice(['A','B','C'])}{random.randint(10000,99999)}",
                       email_de(contacto), ciudad_random()])
write("addressee", ["addressee_id", "full_name", "document_type", "document_number", "address", "mobile_phone", "contact_name",
                    "purchase_order_number", "order_number", "invoice_reference", "email", "city_id"], addressees)
addr_city = {a[0]: a[-1] for a in addressees}
send_city = {s[0]: s[-1] for s in senders}

# ---------------- employee (50, uno por centro) ----------------
roles = ["Coordinador de Centro", "Mensajero", "Auxiliar Logístico", "Operador de Bodega", "Conductor", "Supervisor de Operaciones", "Analista de Novedades", "Auxiliar de Servicio al Cliente"]
employees = []
emp_of_center = {}
for i, c in enumerate(centers, start=1):
    rol = "Coordinador de Centro" if c[0].endswith("-01") and random.random() < 0.4 else random.choice(roles[1:])
    employees.append([i, persona(), rol, celular(), c[0]])
    emp_of_center[c[0]] = i
write("employee", ["employee_id", "name", "job_role", "phone", "center_code"], employees)

# ---------------- shipment + package (1000) ----------------
servicios = {"Mensajería Express": (1, 3), "Paquetería Estándar": (2, 6), "Carga Masiva": (3, 8), "Documentos": (1, 3), "Mismo Día": (0, 0)}
embalajes = ["Caja de cartón", "Sobre", "Bolsa plástica", "Caja reforzada", "Estiba", "Tula", "Rollo"]
contenidos = ["Prendas de vestir", "Calzado deportivo", "Documentos contractuales", "Repuestos de motocicleta", "Celular y accesorios", "Libros universitarios", "Medicamentos de venta libre", "Electrodoméstico pequeño", "Productos de belleza", "Juguetes", "Herramientas manuales", "Equipo de cómputo portátil", "Suplementos nutricionales", "Artesanías", "Café empacado", "Bolsos y accesorios", "Papelería de oficina", "Pequeños electrodomésticos", "Insumos agrícolas", "Material publicitario"]
inicio = datetime(2026, 7, 1, 6, 0)
fin = datetime(2026, 11, 6, 18, 0)
span = int((fin - inicio).total_seconds())

shipments, packages = [], []
tracks = []
for i in range(1, 1001):
    adm = inicio + timedelta(seconds=random.randint(0, span))
    adm = adm.replace(hour=random.randint(7, 18), second=0, microsecond=0)
    tracks.append(adm)
tracks.sort()
ship_info = []
for i, adm in enumerate(tracks, start=1):
    tn = f"5{adm:%m%d}{i:06d}"  # 11 dígitos, estilo guía Coordinadora
    serv = random.choices(list(servicios), [30, 40, 10, 15, 5])[0]
    sid = random.randint(1, 200); aid = random.randint(1, 200)
    if serv == "Mismo Día":   # misma ciudad
        while addr_city[aid] != send_city[sid] and random.random() < 0.97:
            aid = random.randint(1, 200)
    tipo_emb = "Sobre" if serv == "Documentos" else ("Estiba" if serv == "Carga Masiva" and random.random()<0.5 else random.choice(["Caja de cartón","Caja de cartón","Bolsa plástica","Caja reforzada","Tula","Rollo"]))
    if serv == "Documentos" or tipo_emb == "Sobre":
        l, w, h = 35, 25, 1; peso = round(random.uniform(0.1, 0.8), 2)
    elif serv == "Carga Masiva":
        l, w, h = random.randint(60, 120), random.randint(40, 100), random.randint(40, 120); peso = round(random.uniform(30, 250), 2)
    else:
        l, w, h = random.randint(15, 70), random.randint(10, 50), random.randint(5, 50); peso = round(random.uniform(0.5, 25), 2)
    vol = round(l * w * h * 400 / 1_000_000, 2)  # factor 400 kg/m3
    cobrable = max(peso, vol)
    declarado = random.choice([20000, 50000, 80000, 100000, 150000, 200000, 300000, 500000, 800000, 1200000, 2500000]) if serv != "Documentos" else random.choice([10000, 20000, 50000])
    base = {"Mensajería Express": 12000, "Paquetería Estándar": 9500, "Carga Masiva": 45000, "Documentos": 8500, "Mismo Día": 15000}[serv]
    flete = round(base + cobrable * random.uniform(900, 1500) + declarado * 0.01, -2)
    dmin, dmax = servicios[serv]
    est = (adm + timedelta(days=random.randint(dmin, dmax))).date()
    pago = random.choices(["Contado", "Crédito", "Contraentrega", "Al cobro"], [40, 30, 20, 10])[0]
    barcode = f"(415)7709998{random.randint(100000,999999)}(8020){tn}"
    shipments.append([tn, barcode, "ADMITIDO", adm.strftime("%Y-%m-%d %H:%M:%S"), serv, declarado, int(flete), pago, est.isoformat(), sid, aid])
    packages.append([i, peso, l, w, h, vol, tipo_emb, random.choice(["Documentos contractuales","Facturas originales","Títulos académicos","Cheques y soportes contables","Documentos legales"]) if tipo_emb == "Sobre" else random.choice([c for c in contenidos if c != "Documentos contractuales"]), declarado,
                     random.choice(["", "", "Frágil", "Manejar con cuidado", "No apilar", "Este lado arriba", "Contiene líquidos", "Entregar en portería"]), tn])
    ship_info.append((tn, adm, sid, aid, serv))
assert len({s[0] for s in shipments}) == 1000

# ---------------- follow_up (1000) + delivery + novelty ----------------
causas = ["Dirección errada o incompleta", "Destinatario ausente", "Destinatario no reside", "Rehusado por el destinatario", "Zona de difícil acceso", "Cerrado en horario de entrega", "Pago contraentrega no disponible", "Datos de contacto incorrectos"]
acciones = ["Se contactó al remitente para confirmar dirección", "Se programó segundo intento de entrega", "Se dejó aviso de visita y se llamó al destinatario", "Se reprogramó la entrega para el día hábil siguiente", "Se gestionó devolución al remitente", "Se escaló al área de servicio al cliente"]
parentesco = ["Titular", "Titular", "Titular", "Cónyuge", "Hijo(a)", "Padre/Madre", "Hermano(a)", "Vecino(a)", "Portero(a)", "Compañero(a) de trabajo", "Recepcionista"]
notas = {
    "RECIBIDO EN CENTRO": ["Ingreso a bodega de origen", "Recibido y clasificado", "Verificado peso y dimensiones"],
    "EN TRANSITO": ["Despachado hacia centro de destino", "En ruta nacional", "Cargado en vehículo de línea"],
    "EN REPARTO": ["Asignado a mensajero para entrega", "Salió a ruta de distribución urbana"],
    "ENTREGADO": ["Entrega exitosa", "Entregado con prueba digital", "Recibido a satisfacción"],
    "NOVEDAD": ["Novedad en la entrega", "No fue posible entregar"],
    "DEVUELTO": ["Devuelto al remitente tras novedad sin solución"],
}
paths = [
    (["ENTREGADO"], 78),
    (["EN TRANSITO"], 6),
    (["EN REPARTO"], 4),
    (["NOVEDAD", "ENTREGADO"], 3),
    (["NOVEDAD", "DEVUELTO"], 1),
    (["NOVEDAD"], 3),
    (["EN TRANSITO", "ENTREGADO"], 5),
]
# Cada envío recibe su(s) evento(s) de seguimiento en orden de admisión;
# los ~40 envíos más recientes quedan solo con estado inicial ADMITIDO.
follow, deliveries, novelties = [], [], []
fid = did = nid = 0
TARGET = 1000
for tn, adm, sid, aid, serv in ship_info:
    if fid >= TARGET:
        break
    edad = (fin - adm).days
    if edad < 3:
        seq = random.choice([["EN TRANSITO"], ["EN REPARTO"], ["ENTREGADO"]])
    else:
        seq = random.choices([p for p, _ in paths], [w for _, w in paths])[0]
    seq = seq[: TARGET - fid]
    dmin, dmax = servicios[serv]
    t = adm
    intentos = 0
    origen = center_for_city(send_city[sid]); destino = center_for_city(addr_city[aid])
    intentos = 0
    for st in seq:
        if st == "ENTREGADO":
            horas = random.randint(max(dmin, 0) * 24 + 3, max(dmax, 0) * 24 + 10) if dmax else random.randint(3, 9)
            if random.random() < 0.08: horas += random.randint(24, 72)   # algunos entregados con retraso
        else:
            horas = random.randint(3, 36)
        t += timedelta(hours=horas, minutes=random.randint(0, 59))
        if t > fin:
            t = fin - timedelta(minutes=random.randint(1, 600))
        cen = origen if st == "EN TRANSITO" else destino
        fid += 1
        follow.append([fid, st, t.strftime("%Y-%m-%d %H:%M:%S"), random.choice(notas[st]), tn, cen, emp_of_center[cen]])
        if st in ("EN REPARTO", "NOVEDAD"):
            intentos += 1
        if st == "NOVEDAD":
            nid += 1
            novelties.append([nid, random.choice(causas), t.strftime("%Y-%m-%d %H:%M:%S"), random.choice([1, 1, 2, 2, 3]), random.choice(acciones), tn])
        if st == "ENTREGADO":
            did += 1
            dest = next(a for a in addressees if a[0] == aid)
            rel = random.choice(parentesco)
            receptor = dest[6] if rel == "Titular" else persona()
            doc = dest[3] if rel == "Titular" else doc_num("CC")
            deliveries.append([did, t.strftime("%Y-%m-%d %H:%M:%S"), receptor, doc, rel,
                               f"pod/{t:%Y/%m}/{tn}_firma.png;pod/{t:%Y/%m}/{tn}_foto.jpg", tn])

write("shipment", ["tracking_number", "barcode", "initial_status", "admission_datetime", "service_type", "declared_value", "freight_value",
                   "payment_method", "estimated_delivery_date", "sender_id", "addressee_id"], shipments)
write("package", ["package_id", "physical_weight", "length", "width", "height", "volumetric_weight", "packaging_type", "content_description",
                  "declared_value", "notes", "tracking_number"], packages)
write("follow_up", ["follow_up_id", "current_status", "event_datetime", "notes", "tracking_number", "center_code", "employee_id"], follow)
write("delivery", ["delivery_id", "delivery_datetime", "receiver_name", "receiver_id_number", "relationship_to_addressee",
                   "digital_proof_of_delivery", "tracking_number"], deliveries)
write("novelty", ["novelty_id", "novelty_cause", "novelty_datetime", "attempts_made", "actions_taken", "tracking_number"], novelties)
